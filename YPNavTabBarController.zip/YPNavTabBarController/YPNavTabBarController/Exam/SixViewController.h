//
//  SixViewController.h
//  YPNavTabBarController
//
//  Created by 胡云鹏 on 15/10/12.
//  Copyright (c) 2015年 MichaelPPP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SixViewController : UIViewController

@end
